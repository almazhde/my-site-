// Счётчик кликов
const btn = document.getElementById('clickBtn');
const counter = document.getElementById('counter');
let clicks = 0;

btn.addEventListener('click', () => {
  clicks++;
  counter.textContent = `Кликов: ${clicks}`;

  // Небольшая анимация кнопки
  btn.style.transform = 'scale(0.95)';
  setTimeout(() => {
    btn.style.transform = '';
  }, 100);
});

// Автогод в подвале
document.getElementById('year').textContent = new Date().getFullYear();

// Плавная прокрутка к якорям
document.querySelectorAll('a[href^="#"]').forEach(link => {
  link.addEventListener('click', e => {
    const target = document.querySelector(link.getAttribute('href'));
    if (target) {
      e.preventDefault();
      target.scrollIntoView({ behavior: 'smooth' });
    }
  });
});

console.log('Сайт загружен!');